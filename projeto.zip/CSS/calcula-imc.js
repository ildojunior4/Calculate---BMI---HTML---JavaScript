var peso = 69;
var altura = 1.83;
var nomePasciente = ILDO;

var paciente {peso : document.getElementById("")};
if(altura != 0){
	var imc = peso / (altura * altura);
    console.log(imc) // 25
}else{
	cosole.log("A altura deve ser maior que 0!");
}
